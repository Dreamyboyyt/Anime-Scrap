package com.talent.animescrap_common.model

data class UpdateDetails(
    val isUpdateAvailable : Boolean,
    val link : String,
    val description : String
)
