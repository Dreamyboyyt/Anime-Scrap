package com.talent.animescrap_common.model

data class SimpleAnime(
    val animeName: String,
    val animeImageURL: String,
    val animeLink: String
)